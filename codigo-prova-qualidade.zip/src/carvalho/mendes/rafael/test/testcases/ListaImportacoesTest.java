package carvalho.mendes.rafael.test.testcases;

import org.openqa.selenium.NotFoundException;

import carvalho.mendes.rafael.browser.BrowserName;
import carvalho.mendes.rafael.po.ListaDeImportacoesPO;
import carvalho.mendes.rafael.po.impl.ListaDeImportacoesPOImpl;
import carvalho.mendes.rafael.test.ATestCase;

/**
 * Este caso de teste valida se:
 * - Verifica se as quantidades apresentadas s�o valores v�lidos
 * - Para cada produto adicionado, o valor total est� correto de acordo com o pre�o e a quantidade
 * - se o valor bruto total apresentado est� correto
 * @author Rafael
 *
 */
public class ListaImportacoesTest extends ATestCase{
	
	ListaDeImportacoesPO listaDeImportacoesPO;
	
	public ListaImportacoesTest( BrowserName browserName ) {
		super(browserName);
		
		listaDeImportacoesPO = new ListaDeImportacoesPOImpl(driver);
	}
	
	@Override
	public boolean runTest( String urlBase ) {
		
		if( driver==null ) {
			System.out.println("Erro ao recuperar o browser. Abortando execu��o.");
			return false;
		}
		
		driver.get(urlBase);
		
		int linha = 2;//a primeira linha � o cabe�alho
		boolean sair = false;//controla se a itera��o deve continuar
		float somaValorTotalCalculado = 0;
		boolean itensProdutoComValoresOk = true;
		
		for( ; sair==false ; linha++ ) {
			
			double precoLido = 0;
			int quantidadeLida = 0;
			double precoTotalLido = 0;
			
			boolean precoValido = true;
			boolean quantidadeValido = true;
			boolean precoTotalValido = true;

			try {
				precoLido = listaDeImportacoesPO.getTabelaProdutosPrecoLinha(linha);
			}catch (NumberFormatException e) {
				precoValido = false;
				itensProdutoComValoresOk = false;
			}catch (NotFoundException e) {
				sair=true;
			}catch (Exception e) {
				
			}
			
			try {
				quantidadeLida = listaDeImportacoesPO.getTabelaProdutosQuantidadeLinha(linha);
			}catch (NumberFormatException e) {
				quantidadeValido = false;
				itensProdutoComValoresOk = false;
			}catch (NotFoundException e) {
				sair=true;
			}catch (Exception e) {
				
			}
			
			try {
				precoTotalLido = listaDeImportacoesPO.getTabelaProdutosTotalLinha(linha);
			}catch (NumberFormatException e) {
				precoTotalValido = false;
				itensProdutoComValoresOk = false;
			}catch (NotFoundException e) {
				sair=true;
			}catch (Exception e) {
				
			}
			
			if(sair==false) {
				System.out.print( "Produto linha "+Integer.toString( linha-1 )+": " );
				System.out.print( ( precoValido ? Double.toString( precoLido )+" - " : "pre�o inv�lido - " ) );
				System.out.print( ( quantidadeValido ? Integer.toString( quantidadeLida )+" - " : "quantidade inv�lida - " ) );
				System.out.print( ( precoTotalValido ? Double.toString( precoTotalLido )+" - " : "pre�o total inv�lido - " ) );
				
				if( precoValido && quantidadeValido && precoTotalValido ) {
					System.out.print( ( precoLido*quantidadeLida==precoTotalLido ? "Valor Ok" : "valor total calculado incorretamente (correto: "+Double.toString(precoLido*quantidadeLida)+")" ) );
					somaValorTotalCalculado+=precoLido*quantidadeLida;
				}
				System.out.println();
			}
		}
		
		boolean valorTituloValido = true;
		boolean valorSubtituloValido = true;
		
		if( itensProdutoComValoresOk ) {
			
			double valorTotalTitulo = 0;
			try {
				valorTotalTitulo = listaDeImportacoesPO.getTotalBrutoTituloPagina();
			}catch (NumberFormatException e) {
				valorTituloValido = false;
			}
			System.out.print( "Valor total no t�tulo da p�gina: "+( valorTituloValido ? Double.toString( valorTotalTitulo ) : "valor inv�lido" ) );
			if( valorTituloValido ) System.out.println( ( somaValorTotalCalculado==valorTotalTitulo ? "" : " - valor incorreto (deveria ser "+Double.toString(somaValorTotalCalculado)+")" ) );
			
			
			double valorTotalSubtitulo = 0;
			try {
				valorTotalSubtitulo = listaDeImportacoesPO.getTotalBrutoSubtitulo();
			}catch (NumberFormatException e) {
				valorSubtituloValido = false;
			}
			System.out.print( "Valor total no sub-t�tulo: "+( valorSubtituloValido ? Double.toString( valorTotalSubtitulo ) : "valor inv�lido" ) );
			if( valorSubtituloValido ) System.out.println( ( somaValorTotalCalculado==valorTotalSubtitulo ? "" : " - valor incorreto (deveria ser "+Double.toString(somaValorTotalCalculado)+")" ) );
			
		}else {
			
			System.out.println("Os valores nos t�tulos n�o foram validados devido aos valores nos produtos estarem com erros");
			
		}
		
		driver.close();
		
		return itensProdutoComValoresOk && valorTituloValido && valorSubtituloValido;
	}
	
}
