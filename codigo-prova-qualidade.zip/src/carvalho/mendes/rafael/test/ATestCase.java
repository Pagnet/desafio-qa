package carvalho.mendes.rafael.test;

import org.openqa.selenium.WebDriver;

import carvalho.mendes.rafael.browser.Browser;
import carvalho.mendes.rafael.browser.BrowserName;
import carvalho.mendes.rafael.browser.impl.BrowserImpl;

/**
 * Classe abstrata para um caso de teste
 * @author Rafael
 *
 */
public abstract class ATestCase {
	
	Browser browser = new BrowserImpl();
	BrowserName browserName;
	
	protected WebDriver driver;
	
	public ATestCase( BrowserName browserName ) {
		this.browserName = browserName;
		driver = browser.getBrowser(browserName);
	}
	
	/**
	 * M�todo chamado para executar o teste
	 * @param urlBase URL para que o teste seja executado
	 * @return TRUE se logrou sucesso. FALSE caso contr�rio
	 */
	public abstract boolean runTest( String urlBase );
	
}
