package carvalho.mendes.rafael.po.impl;

import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import carvalho.mendes.rafael.po.ListaDeImportacoesPO;

public class ListaDeImportacoesPOImpl implements ListaDeImportacoesPO{
	
	WebDriver driver;
	
	By byPrecoTituloTela = By.xpath("//h2//price");
	By byPrecoSubtituloTela = By.xpath("//div[@id='importer-status-imported']//price");
	String locatorPreco = "//table[@class='importer-purchases-table']//tr[$$$]/td[3]";
	String locatorQuantidade = "//table[@class='importer-purchases-table']//tr[$$$]/td[4]";
	String locatorTotal = "//table[@class='importer-purchases-table']//tr[$$$]/td[5]";
	
	public ListaDeImportacoesPOImpl( WebDriver driver ) {
		if(driver==null) throw  new NullPointerException();
		this.driver=driver;
	}
	
	public double getTotalBrutoTituloPagina() throws NumberFormatException{
		String txtPrecoTotal = driver.findElement(byPrecoTituloTela).getText();
		
		double valor ;
		valor = Double.parseDouble( txtPrecoTotal.replace("R$", "").replace(',', '.') );//considera o formato 'R$ #'
		return valor;
	}
	
	public double getTotalBrutoSubtitulo() throws NumberFormatException{
		String txtPrecoTotal = driver.findElement(byPrecoSubtituloTela).getText();
		
		double valor = Double.parseDouble( txtPrecoTotal.replace("R$", "").replace(',', '.') );//considera o formato 'R$ #'
		return valor;
	}
	
	public double getTabelaProdutosPrecoLinha( int linha ) throws NumberFormatException, NotFoundException{
		String locatorFinal = locatorPreco.replace("$$$", Integer.toString(linha) );
		By byPrecoLinha = By.xpath(locatorFinal);
		
		WebElement element = driver.findElement(byPrecoLinha);
		if( element==null ) throw new NotFoundException("Elemento n�o encontrado");
		
		String txtPrecoLinha = element.getText();
		double valor = Double.parseDouble( txtPrecoLinha.replace("R$", "").replace(',', '.') );//considera o formato 'R$ #'
		
		return valor;
	}
	
	public int getTabelaProdutosQuantidadeLinha( int linha ) throws NumberFormatException, NotFoundException{
		String locatorFinal = locatorQuantidade.replace("$$$", Integer.toString(linha) );
		By byQuantidadeLinha = By.xpath(locatorFinal);
		
		WebElement element = driver.findElement(byQuantidadeLinha);
		if( element==null ) throw new NotFoundException("Elemento n�o encontrado");
		
		String txtPrecoLinha = element.getText();
		int valor = Integer.parseInt( txtPrecoLinha );
		
		return valor;
	}
	
	public double getTabelaProdutosTotalLinha( int linha ) throws NumberFormatException, NotFoundException{
		String locatorFinal = locatorTotal.replace("$$$", Integer.toString(linha) );
		By byPrecoTotalLinha = By.xpath(locatorFinal);
		
		WebElement element = driver.findElement(byPrecoTotalLinha);
		if( element==null ) throw new NotFoundException("Elemento n�o encontrado");
		
		String txtPrecoTotalLinha = element.getText();
		double valor = Double.parseDouble( txtPrecoTotalLinha.replace("R$", "").replace(',', '.') );//considera o formato 'R$ #'
		
		return valor;
	}
	
}
