package carvalho.mendes.rafael.po;

import org.openqa.selenium.NotFoundException;

public interface ListaDeImportacoesPO {
	
	/**
	 * Recupera o total apresentado no t�tulo principal da tela
	 * @return O valor Total da importa��o apresentado no t�tulo principal da tela, caso exista
	 * @throws NumberFormatException Caso o valor total n�o esteja no formato esperado (R$ 9999,99)
	 */
	public double getTotalBrutoTituloPagina() throws NumberFormatException;
	
	/**
	 * Recupera o total apresentado no sub t�tulo da tela
	 * @return O valor Total da importa��o apreentado no subt�tulo, caso exista
	 * @throws NumberFormatException Caso o valor total n�o esteja no formato esperado (R$ 9999,99)
	 */
	public double getTotalBrutoSubtitulo() throws NumberFormatException;
	
	/**
	 * Recupera o pre�o apresentado para uma determinada linha da tabela de produtos selecionados da importa��o
	 * @param linha Linha a ser lida
	 * @return O pre�o do produto da linha selecionada
	 * @throws NumberFormatException Caso o valor n�o esteja no formato esperado (R$ 99999,99)
	 * @throws NotFoundException Caso a linha seja inv�llida, ou n�o exista.
	 */
	public double getTabelaProdutosPrecoLinha( int linha ) throws NumberFormatException, NotFoundException;
	
	/**
	 * Recupera a quantidade de produtos de uma determinada linha da tabela de produtos selecionados da importa��o
	 * @param linha linha Linha a ser lida
	 * @return A quantidade do produto da linha selecionada
	 * @throws NumberFormatException Caso a quantidade n�o esteja no formato esperado (99999)
	 * @throws NotFoundException Caso a linha seja inv�llida, ou n�o exista.
	 */
	public int getTabelaProdutosQuantidadeLinha( int linha ) throws NumberFormatException, NotFoundException;
	
	/**
	 * Recupera o valor total de uma determinada linha da tabela de produtos selecionados da importa��o
	 * @param linha linha Linha a ser lida
	 * @return O valor total da linha selecionada
	 * @throws NumberFormatException Caso o valor n�o esteja no formato esperado (R$ 99999,99)
	 * @throws NotFoundException Caso a linha seja inv�llida, ou n�o exista.
	 */
	public double getTabelaProdutosTotalLinha( int linha ) throws NumberFormatException, NotFoundException;
	
}
