package carvalho.mendes.rafael.main;

import carvalho.mendes.rafael.browser.BrowserName;
import carvalho.mendes.rafael.test.testcases.ListaImportacoesTest;

public class MainTest {

	public static void main(String[] args) {
		
		System.out.println("Chrome ----------");
		ListaImportacoesTest importacoesTestChrome = new ListaImportacoesTest(BrowserName.chrome);
		importacoesTestChrome.runTest( "https://desafio-qa.herokuapp.com/" );
		
		System.out.println();
		System.out.println("Firefox ----------");
		ListaImportacoesTest importacoesTestFirefox = new ListaImportacoesTest(BrowserName.firefox);
		importacoesTestFirefox.runTest( "https://desafio-qa.herokuapp.com/" );
		
	}
	
}
