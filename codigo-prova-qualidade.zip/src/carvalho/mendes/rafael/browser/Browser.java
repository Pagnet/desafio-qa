package carvalho.mendes.rafael.browser;

import org.openqa.selenium.WebDriver;

public interface Browser {
	
	public WebDriver getBrowser( BrowserName browser );

}
