package carvalho.mendes.rafael.browser;

public enum BrowserName {
	chrome,
	firefox,
	ie
}
